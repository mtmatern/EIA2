var endabgabe;
(function (endabgabe) {
    class SeaworldThings {
        constructor() {
            //;
        }
        move() {
            //;
        }
        draw() {
            //;
        }
        update() {
            this.move();
            this.draw();
        }
    }
    endabgabe.SeaworldThings = SeaworldThings;
})(endabgabe || (endabgabe = {}));
//# sourceMappingURL=SeaworldThings.js.map