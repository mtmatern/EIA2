namespace endabgabe{
    export class SeaworldThings {
        x: number;
        y: number;
        
        dx: number;
        dy: number;

        hitboxRadius: number;
        hitboxRadiusY: number;

        color: string;

        constructor() {
            //;
        }

        move(): void {
            //;
        }

        draw(): void {
            //;
        }

        update(): void {
            this.move();
			this.draw();
        }


    }
}