interface Score {
    [key: string]: string;
}

interface Player {
    name: string;
    score: number;
}